package com.nilfactor.activity3.controller;

import com.nilfactor.activity3.business.BusinessInterface;
import com.nilfactor.activity3.business.BusinessService;
import com.nilfactor.activity3.model.MusicAlbum;
import data.MusicAlbumEntityRepository;
import entity.MusicAlbumEntity;

import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import javax.faces.bean.ManagedBean;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@ManagedBean
@SessionScoped
public class SongController {
    @Inject
    BusinessInterface services;

    public BusinessInterface getService() {
        List<MusicAlbumEntity> musicAlbumEntityList = MusicAlbumEntityRepository.findAllOrderedById();
        services.setAllMusicAlbums(musicAlbumEntityList);
        return services;
    }

    public String addAlbum() {
        FacesContext context = FacesContext.getCurrentInstance();
        MusicAlbum musicAlbum = context.getApplication().evaluateExpressionGet(context, "#{musicAlbum}", MusicAlbum.class);
//        services.test();
        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("musicAlbum", musicAlbum);
        services.addAlbum(musicAlbum);
        System.out.println("Added album");

        try {
            MusicAlbumEntity mae = new MusicAlbumEntity();
            mae.setAlbum(musicAlbum.getAlbum());
            mae.setArtist(musicAlbum.getArtist());
            mae.setSong1(musicAlbum.getSong1());
            mae.setSong2(musicAlbum.getSong2());
            mae.setSong3(musicAlbum.getSong3());
            mae.setSong4(musicAlbum.getSong4());
            mae.setSong5(musicAlbum.getSong5());
            mae.setSong6(musicAlbum.getSong6());
            mae.setSong7(musicAlbum.getSong7());
            mae.setSong8(musicAlbum.getSong8());
            mae.setSong9(musicAlbum.getSong9());
            mae.setSong10(musicAlbum.getSong10());

            MusicAlbumEntityRepository.saveMusicAlbumEntity(mae);
            System.out.println("Added album");

            HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            HttpServletResponse res = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
            res.sendRedirect(req.getContextPath() + "/app/home.xhtml");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
        }
        return "home.xhtml";
    }

    public String getDetails() {
        FacesContext context = FacesContext.getCurrentInstance();
        MusicAlbum musicAlbum = context.getApplication().evaluateExpressionGet(context, "#{musicAlbum}", MusicAlbum.class);
        services.test();
        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("musicAlbum", musicAlbum);
        System.out.println("retrieving album details");
        return "home.xhtml";
    }
}
