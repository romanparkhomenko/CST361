package data;

import com.nilfactor.activity3.logic.LoggingInterceptor;
import entity.MusicAlbumEntity;
import entity.UserEntity;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.interceptor.Interceptors;
import java.util.ArrayList;
import java.util.List;

public class MusicAlbumEntityRepository {
	 public static void saveMusicAlbumEntity(MusicAlbumEntity mae) {
		 Transaction transaction = null;
	     try {
	       	Session session = HibernateUtil.getSessionFactory().openSession();
	        			
	        // start a transaction
	        transaction = session.beginTransaction();
	        session.save(mae);
	        
	        // commit transaction
	       transaction.commit();
	     } catch (Exception e) {
	    	 if (transaction != null) {
	    		 transaction.rollback();
	         }
	         e.printStackTrace();
	     }
	 }


	 @SuppressWarnings("unchecked")
	 public static MusicAlbumEntity findAlbumByAlbumName(String album) {
		 Transaction transaction = null;
		 try {
			// start a transaction
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			transaction = session.beginTransaction();
			
			String hql = "select u from entity.MusicAlbumEntity u where album = :album";
			List<MusicAlbumEntity> results = session.createQuery(hql)
					.setParameter("album", album)
					.list();
			
			transaction.commit();
			
//			System.out.println("Size => " + results.size());
			
			if (results.size() > 0) {
				return results.get(0);
			}
	     } catch (Exception e) {
	    	 if (transaction != null) {
	    		 transaction.rollback();
	         }
	         e.printStackTrace();
	     }
		 return new MusicAlbumEntity();
	 }
	 
	 @SuppressWarnings("unchecked")
	 public static List<MusicAlbumEntity> findAllOrderedById() {
		 Transaction transaction = null;
		 try {
			 Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			 transaction = session.beginTransaction();
			 Query q = session.createQuery("select u from entity.MusicAlbumEntity u");
			 List<MusicAlbumEntity> albums = q.list();
			 
			 transaction.commit();
			 return albums;
		 } catch (Exception e) {
			 if (transaction != null) {
	    		 transaction.rollback();
	         }
	         e.printStackTrace();
	     }
		 
		 return new ArrayList<MusicAlbumEntity>();
	 }
}
