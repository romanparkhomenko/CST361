package com.nilfactor.activity3.database;

import com.nilfactor.activity3.model.User;

public class DataLoginService {
	public static boolean isValidLogin(User user, String username, String password) {
		// username must match, password must match
		return username.equals(user.getUsername())
			&& password.equals(user.getPassword());
	}
}
