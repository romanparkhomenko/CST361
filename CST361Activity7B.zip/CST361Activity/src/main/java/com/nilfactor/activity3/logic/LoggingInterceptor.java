package com.nilfactor.activity3.logic;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
public class LoggingInterceptor {

    private LoggerService logger = new LoggerService();

    @AroundInvoke
    public Object methodInterceptor(InvocationContext ctx) throws Exception {
        boolean success = true;
        logger.LogInfo(ctx);
        //Get parameters from executing method if needed
        try {
            return ctx.proceed();
        } catch (Exception e) {
            success = false;
            logger.LogError(ctx, e);
            logger.LogInfoSuccess(ctx, success);
            return null;
        } finally{
            if (success) {
                logger.LogInfoSuccess(ctx, success);
            }
        }
    }
}