package com.nilfactor.activity3.logic;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.interceptor.InvocationContext;

public class LoggerService {

    private static final Logger logger = LogManager.getLogger(LoggerService.class);

    public void LogDebug(InvocationContext ctx) {
        logger.debug("Debug info for: " + ctx.getMethod().getName());
    }
    public void LogInfo (InvocationContext ctx) {
        logger.info("Intercepting: " + ctx.getMethod().getName());
    }
    public void LogWarning (InvocationContext ctx) {
        logger.warn("Warning in: " + ctx.getMethod().getName());
    }
    public void LogError(InvocationContext ctx, Exception e) {
        logger.error("Error in: " + ctx.getMethod().getName() + " Exception: "+ e.toString());
    }
    public void LogInfoSuccess (InvocationContext ctx, boolean result) {
        logger.info("Method: " + ctx.getMethod().getName() + " Execution Success: " + result);
    }
}
