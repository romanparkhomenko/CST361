package com.nilfactor.activity3.business;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.interceptor.InterceptorBinding;
import javax.interceptor.Interceptors;

import com.nilfactor.activity3.logic.Log;
import com.nilfactor.activity3.logic.LogLevel;
import com.nilfactor.activity3.logic.LoggingInterceptor;
import com.nilfactor.activity3.model.MusicAlbum;
import data.MusicAlbumEntityRepository;
import entity.MusicAlbumEntity;

@Stateless
@Local(BusinessInterface.class)
@Alternative
@Log(LogLevel.SEVERE)
public class BusinessService implements BusinessInterface {
	List<MusicAlbum> musicAlbums = new ArrayList<MusicAlbum>();
	List<MusicAlbumEntity> allMusicAlbums = new ArrayList<MusicAlbumEntity>();

	@Override
	public void test() {
		System.out.println("Facade");
	}

	@Override
	public List<MusicAlbum> getMusicAlbums() {
		return musicAlbums;
	}

	@Override
	public void setMusicAlbums(List<MusicAlbum> musicAlbums) {
		this.musicAlbums = musicAlbums;
	}

	@Override
	public List<MusicAlbumEntity> getAllMusicAlbums() {
		return MusicAlbumEntityRepository.findAllOrderedById();
	}

	@Override
	public void setAllMusicAlbums(List<MusicAlbumEntity> musicAlbums) {
		this.allMusicAlbums = musicAlbums;
	}

	public BusinessService() {

		musicAlbums.add(new MusicAlbum("Where I Won't Be Found", "Seven Lions", "Freesol", "Where I Won't Be Found", "Slow Dive", "Sun Won't Rise", "Rescue Me", "Without You My Love", "Steps of Deep Slumber", "Silent Skies", null, null));
	}

	@Override
	public void addAlbum(MusicAlbum musicAlbum) {
		musicAlbums.add(musicAlbum);
	}

	@Override
	public void addAlbumToDB(MusicAlbumEntity musicAlbum) {
		allMusicAlbums.add(musicAlbum);
		MusicAlbumEntityRepository.saveMusicAlbumEntity(musicAlbum);
	}
}
