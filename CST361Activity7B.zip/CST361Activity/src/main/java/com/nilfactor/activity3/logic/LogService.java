package com.nilfactor.activity3.logic;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import javax.ejb.Stateless;
import java.util.logging.Level;
import java.util.logging.Logger;

@Stateless
public class LogService {
    // Receives the class name decorated with @Log
    public void log(final String className, final LogLevel level, final String
            message) {
        // Logger from package java.util.logging
        Logger log = Logger.getLogger(className);
        log.log(Level.parse(level.toString()), message);
    }
}