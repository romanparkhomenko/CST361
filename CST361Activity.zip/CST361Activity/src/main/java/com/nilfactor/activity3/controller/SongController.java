package com.nilfactor.activity3.controller;

import com.nilfactor.activity3.business.BusinessInterface;
import com.nilfactor.activity3.model.MusicAlbum;

import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import javax.faces.bean.ManagedBean;

@ManagedBean
@SessionScoped
public class SongController {
    @Inject
    BusinessInterface services;

    public BusinessInterface getService() {
        return services;
    }

    public String addAlbum() {
        FacesContext context = FacesContext.getCurrentInstance();
        MusicAlbum musicAlbum = context.getApplication().evaluateExpressionGet(context, "#{musicAlbum}", MusicAlbum.class);
        services.test();
        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("musicAlbum", musicAlbum);
        services.addAlbum(musicAlbum);
        System.out.println("Added album");
        return "home.xhtml";
    }

    public String getDetails() {
        FacesContext context = FacesContext.getCurrentInstance();
        MusicAlbum musicAlbum = context.getApplication().evaluateExpressionGet(context, "#{musicAlbum}", MusicAlbum.class);
        services.test();
        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("musicAlbum", musicAlbum);
        System.out.println("retrieving album details");
        return "home.xhtml";
    }
}
