package com.nilfactor.activity3.rest;

import com.nilfactor.activity3.business.BusinessInterface;
import com.nilfactor.activity3.business.BusinessService;
import entity.MusicAlbumEntity;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@RequestScoped
@Path("/album")
@Produces({"application/xml", "application/json"})
@Consumes({"application/xml", "application/json"})
public class MusicAlbumRestService {
    @Inject
    BusinessInterface bs;

    public MusicAlbumRestService() {

    }

    @GET
    @Path("/getjson")
    @Produces(MediaType.APPLICATION_JSON)
    public List<MusicAlbumEntity> getAllJson() {
        return this.bs.getAllMusicAlbums();
    }

    // POST Request to Add New Album
    @POST
    @Path("/addAlbum")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public String addProduct(@FormParam("album") String album,
                             @FormParam("artist") String artist,
                             @FormParam("song1") String song1,
                             @FormParam("song2") String song2,
                             @FormParam("song3") String song3,
                             @FormParam("song4") String song4,
                             @FormParam("song5") String song5,
                             @FormParam("song6") String song6,
                             @FormParam("song7") String song7,
                             @FormParam("song8") String song8,
                             @FormParam("song9") String song9,
                             @FormParam("song10") String song10) {
        MusicAlbumEntity musicAlbum = new MusicAlbumEntity();
        musicAlbum.setAlbum(album);
        musicAlbum.setArtist(artist);
        musicAlbum.setSong1(song1);
        musicAlbum.setSong2(song2);
        musicAlbum.setSong3(song3);
        musicAlbum.setSong4(song4);
        musicAlbum.setSong5(song5);
        musicAlbum.setSong6(song6);
        musicAlbum.setSong7(song7);
        musicAlbum.setSong8(song8);
        musicAlbum.setSong9(song9);
        musicAlbum.setSong10(song10);

        this.bs.addAlbumToDB(musicAlbum);
        return "SUCCESSFULLY ADDED ALBUM";
    }

}
