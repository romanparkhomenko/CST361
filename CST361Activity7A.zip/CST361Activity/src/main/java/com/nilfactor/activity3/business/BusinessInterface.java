package com.nilfactor.activity3.business;

import java.util.List;

import javax.ejb.Local;

import com.nilfactor.activity3.model.MusicAlbum;
import entity.MusicAlbumEntity;

@Local
public interface BusinessInterface {
	public void test();
	public List<MusicAlbum> getMusicAlbums();
	public void setMusicAlbums(List<MusicAlbum> musicAlbums);
	public void addAlbum(MusicAlbum musicAlbum);

	public List<MusicAlbumEntity> getAllMusicAlbums();
	public void setAllMusicAlbums(List<MusicAlbumEntity> musicAlbums);
	public void addAlbumToDB(MusicAlbumEntity musicAlbum);
}
