package entity;

import org.hibernate.validator.constraints.NotEmpty;

import javax.faces.bean.ManagedBean;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@ManagedBean
@Entity(name = "entity.MusicAlbumEntity")
@XmlRootElement
@Table(name = "albums", uniqueConstraints = @UniqueConstraint(columnNames = "id"))
public class MusicAlbumEntity implements Serializable {
	/**
     * Default value included to remove warning. Remove or modify at will.
     **/
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "id", unique=true, nullable = false)
    private Long id;
    
    @NotNull
    @NotEmpty
    @Column(name="album")
    private String album;

    @NotNull
    @NotEmpty
    @Column(name="artist")
	private String artist;

    @Column(name="song1")
	private String song1;

	@Column(name="song2")
	private String song2;

	@Column(name="song3")
	private String song3;

	@Column(name="song4")
	private String song4;

	@Column(name="song5")
	private String song5;

	@Column(name="song6")
	private String song6;

	@Column(name="song7")
	private String song7;

	@Column(name="song8")
	private String song8;

	@Column(name="song9")
	private String song9;

	@Column(name="song10")
	private String song10;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getSong1() {
		return song1;
	}

	public void setSong1(String song1) {
		this.song1 = song1;
	}

	public String getSong2() {
		return song2;
	}

	public void setSong2(String song2) {
		this.song2 = song2;
	}

	public String getSong3() {
		return song3;
	}

	public void setSong3(String song3) {
		this.song3 = song3;
	}

	public String getSong4() {
		return song4;
	}

	public void setSong4(String song4) {
		this.song4 = song4;
	}

	public String getSong5() {
		return song5;
	}

	public void setSong5(String song5) {
		this.song5 = song5;
	}

	public String getSong6() {
		return song6;
	}

	public void setSong6(String song6) {
		this.song6 = song6;
	}

	public String getSong7() {
		return song7;
	}

	public void setSong7(String song7) {
		this.song7 = song7;
	}

	public String getSong8() {
		return song8;
	}

	public void setSong8(String song8) {
		this.song8 = song8;
	}

	public String getSong9() {
		return song9;
	}

	public void setSong9(String song9) {
		this.song9 = song9;
	}

	public String getSong10() {
		return song10;
	}

	public void setSong10(String song10) {
		this.song10 = song10;
	}
}